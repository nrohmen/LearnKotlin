# LearnKotlin
Learn Kotlin with Retrofit and RxAndroid to consume data from an API.
For more detail and explanation, feel free to read this article https://medium.com/@nurrohman/belajar-kotlin-dengan-retrofit-dan-rxandroid-12ce08ad32eb.
